package com.printer.sdk.demo.util;

public class Constants {

    public static final int SearchTypeAll = 0;
    public static final int SearchTypeBle = 1;
    public static final int SearchTypeUsb = 2;
    public static final int SearchTypeWifi = 3;
    public static final int SearchTypeSer = 4;
}
