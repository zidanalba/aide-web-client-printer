package com.printer.sdk.demo.bean;

import android.graphics.Bitmap;

import java.io.File;

public class Triple {
    public Triple(int index,Bitmap bitmap){
        this.index = index;
        this.bitmap = bitmap;
    }
    public int index;
    public File file;
    public Bitmap bitmap;
}
