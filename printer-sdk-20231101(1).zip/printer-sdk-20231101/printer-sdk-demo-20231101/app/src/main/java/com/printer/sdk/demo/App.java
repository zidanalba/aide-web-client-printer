package com.printer.sdk.demo;

import android.app.Application;

import com.printer.sdk2.Printer;


/**
 * @author mxlei
 * @date 2021/12/7
 */
public class App extends Application {

    public static Application app;

    @Override
    public void onCreate() {
        super.onCreate();
        app = this;
        // enable log
        Printer.setLogEnable(true, null);
    }

}
