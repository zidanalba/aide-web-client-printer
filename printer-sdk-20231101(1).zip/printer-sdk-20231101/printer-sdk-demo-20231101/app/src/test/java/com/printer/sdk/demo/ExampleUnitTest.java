package com.printer.sdk.demo;

import org.junit.Assert;
import org.junit.Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.regex.Pattern;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        Pattern jsonPattern = Pattern.compile("^[\\[{][\\d\\D]*[]}]$");
        try {
            FileInputStream fi = new FileInputStream("/home/mxlei/Documents/奶茶.json");
//            FileInputStream fi = new FileInputStream("/home/mxlei/a.json");
            byte[] data = new byte[3*1024];
            int len = fi.read(data, 0, data.length);
            String str = new String(data, 0, len).trim();
//            System.out.println("data = " + str);
            boolean match = jsonPattern.matcher(str).matches();
            Assert.assertTrue(match);
            fi.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}