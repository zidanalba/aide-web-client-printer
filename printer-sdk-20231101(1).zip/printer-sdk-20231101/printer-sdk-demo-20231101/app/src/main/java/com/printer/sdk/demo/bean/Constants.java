package com.printer.sdk.demo.bean;

public class Constants {

    //打印速度
    public static final String KEY_PRINT_SPEED = "key_print_speed";
    //打印分辨率
    public static final String KEY_PRINT_DPI = "key_print_dpi";
    //打印浓度
    public static final String KEY_PRINT_DENSITY = "key_print_density";
    //纸张类型
    public static final String KEY_PRINT_PAPER_TYPE= "key_print_paper_type";
    //打印方向
    public static final String KEY_PRINT_DIRECTION= "key_print_print_direction";

}
